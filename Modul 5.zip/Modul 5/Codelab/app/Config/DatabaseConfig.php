<?php

namespace app\Config;

class DatabaseConfig 
{
    // Setting konfigurasi database kalian
    public $host = "localhost";
    public $user = "root";
    public $password = "";
    public $database_name = "praktikum";
    public $port = 3308;
}